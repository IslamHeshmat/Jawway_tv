package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import pages.HomePage;

import java.time.Duration;

public class BaseTest {

        public static WebDriver webdriver;
        protected HomePage homepageobject;

        @BeforeClass
        public void setUp(){
            ChromeOptions co = new ChromeOptions();
            co.addArguments("--remote-allow-origins=*");
            WebDriver webdriver = new ChromeDriver(co);
         //   ChromeDriver webdriver = new ChromeDriver();
            webdriver.manage().window().maximize();
            webdriver.navigate().to("https://subscribe.jawwy.tv/ae-ar");
            homepageobject= new HomePage(webdriver);




        }
       @AfterClass
        public void tearDown()
        {
            homepageobject.webdriver.close();
        }
    }

