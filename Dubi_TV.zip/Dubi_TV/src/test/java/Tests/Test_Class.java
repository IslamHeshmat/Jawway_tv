package Tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test_Class extends BaseTest {

    @Test
    public void Verify_That_three_plans_are_displayed_when_Egypt_selected() {

        homepageobject.user_can_open_countries_dropdown();
        homepageobject.select_country_from_dropdown("مصر");


        //check if the three plans are Displayed
        boolean is_Lite_plan_Displayed;
        is_Lite_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-لايت")).isEnabled();
        Assert.assertTrue(is_Lite_plan_Displayed);

        boolean is_Classic_plan_Displayed;
        is_Classic_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-الأساسية")).isEnabled();
        Assert.assertTrue(is_Classic_plan_Displayed);

        boolean is_Premium_plan_Displayed;
        is_Premium_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-بريميوم")).isEnabled();
        Assert.assertTrue(is_Premium_plan_Displayed);
    }

    @Test(dependsOnMethods = "Verify_That_three_plans_are_displayed_when_Egypt_selected")

    public void Verify_That_currency_is_equal_Pound_when_Egypt_selected() {
        //  check if the currency =جنيه مصري
        By Egypt_currency = By.id("kamOldPriceLableOnTheBanner");
        Assert.assertTrue(homepageobject.webdriver.findElement(Egypt_currency).getText().contains("جنيه مصري"));

    }//div[@class='lined']//div[2]

    @Test

    public void Verify_That_Price_is_Displayed_when_Egypt_selected() {
        // please note i did not want to compare the price with a specific amount of money cuz this of-course will change in the future
        boolean check_price_Subscription;
        check_price_Subscription = homepageobject.webdriver.findElement(By.cssSelector(" div[class='trial-cost'] b")).isDisplayed();
        Assert.assertTrue(check_price_Subscription);

    }

    //************************************************************
    //***************************
    @Test
    public void Verify_That_three_plans_are_displayed_when_Jordan_selected() {

        homepageobject.user_can_open_countries_dropdown();
        homepageobject.select_country_from_dropdown("الأردن");


        //check if the three plans are Displayed
        boolean is_Lite_plan_Displayed;
        is_Lite_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-لايت")).isEnabled();
        Assert.assertTrue(is_Lite_plan_Displayed);

        boolean is_Classic_plan_Displayed;
        is_Classic_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-الأساسية")).isEnabled();
        Assert.assertTrue(is_Classic_plan_Displayed);

        boolean is_Premium_plan_Displayed;
        is_Premium_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-بريميوم")).isEnabled();
        Assert.assertTrue(is_Premium_plan_Displayed);
    }

    @Test(dependsOnMethods = "Verify_That_three_plans_are_displayed_when_Jordan_selected")

    public void Verify_That_currency_is_equal_Dirham_when_Jordan_selected() {
        //  check if the currency =درهم أردني
        By Jordan_currency = By.xpath("//div[@class='trial-cost']");
        Assert.assertTrue(homepageobject.webdriver.findElement(Jordan_currency).getText().contains("دينار أردني"));

    }//div[@class='lined']//div[2]

    @Test

    public void Verify_That_Price_is_Displayed_when_Jordan_selected() {
        // please note i did not want to compare the price with a specific amount of money cuz this of-course will change in the future
        boolean check_price_Subscription;
        check_price_Subscription = homepageobject.webdriver.findElement(By.cssSelector("div[class='trial-cost'] b")).isDisplayed();
        Assert.assertTrue(check_price_Subscription);

    }

    //************************************************************
    //***************************
    @Test
    public void Verify_That_three_plans_are_displayed_when_UAEselected() {


        //check if the three plans are Displayed
        boolean is_Lite_plan_Displayed;
        is_Lite_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-لايت")).isEnabled();
        Assert.assertTrue(is_Lite_plan_Displayed);

        boolean is_Classic_plan_Displayed;
        is_Classic_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-الأساسية")).isEnabled();
        Assert.assertTrue(is_Classic_plan_Displayed);

        boolean is_Premium_plan_Displayed;
        is_Premium_plan_Displayed = homepageobject.webdriver.findElement(By.id("name-بريميوم")).isEnabled();
        Assert.assertTrue(is_Premium_plan_Displayed);
    }

    @Test

    public void Verify_That_currency_is_equal_UAE_DIRAHM_when_UAE_selected() {
        //  check if the currency =دينار اماراتي
        By UAE_currency = By.xpath("//div[@class='trial-cost']");
        Assert.assertTrue(homepageobject.webdriver.findElement(UAE_currency).getText().contains("درهم إماراتي"));

    }

    @Test(dependsOnMethods = "Verify_That_three_plans_are_displayed_when_UAEselected")

    public void Verify_That_Price_is_Displayed_when_UAE_selected() {
        // please note i did not want to compare the price with a specific amount of money cuz this of-course will change in the future
        boolean check_price_Subscription;
        check_price_Subscription = homepageobject.webdriver.findElement(By.cssSelector("div[class='trial-cost'] b")).isDisplayed();
        Assert.assertTrue(check_price_Subscription);

    }
}
