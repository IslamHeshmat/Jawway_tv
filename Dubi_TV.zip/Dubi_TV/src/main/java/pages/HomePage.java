package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    public WebDriver webdriver;
    // create constractor
    public HomePage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }


     By country_dropdown =By.id("country-name");
    By Jordan_country=By.id("jo");
    By Egypt_country=By.id("eg");



    public void user_can_open_countries_dropdown()
    {
        webdriver.findElement(country_dropdown).click();
    }
    public void select_Jordan_country_from_dropdown()
    {
        webdriver.findElement(Jordan_country).click();
    }
    public void select_Egypt_country_from_dropdown()
    {
        webdriver.findElement(Egypt_country).click();
    }

    public void select_country_from_dropdown(String country)
    {
        webdriver.findElement(By.xpath("//span[contains(text(),'"+country+"')]")).click();

    }





}

